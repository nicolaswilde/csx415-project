library(devtools)
install(".")